/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author blanc
 */
public class Enc_satisfaccion {
    private int id_Enc_satisfaccion;
    private String Pregunta;
    private String Enviar;

    public Enc_satisfaccion(int Enc_satisfaccion, String Pregunta, String Enviar) {
        this.id_Enc_satisfaccion = Enc_satisfaccion;
        this.Pregunta = Pregunta;
        this.Enviar = Enviar;
    }

    public int getEnc_satisfaccion() {
        return id_Enc_satisfaccion;
    }

    public String getPregunta() {
        return Pregunta;
    }

    public String getEnviar() {
        return Enviar;
    }

    public void setId_Enc_satisfaccion(int id_Enc_satisfaccion) {
        this.id_Enc_satisfaccion = id_Enc_satisfaccion;
    }

    public void setPregunta(String Pregunta) {
        this.Pregunta = Pregunta;
    }

    public void setEnviar(String Enviar) {
        this.Enviar = Enviar;
    }
    
    public String mostrardatos() {
        return "id_Enc_satisfaccion{" + "id_Enc_satisfaccion=" + id_Enc_satisfaccion + ", Pregunta=" + Pregunta + ", Enviar=" + Enviar + '}';
    }
    
    
}
