/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Pag_principal {
    private int id_Pag_principal;
    private String Ruleta_de_imagenes;
    private String Productos;

    public Pag_principal(int id_Pag_principal, String Ruleta_de_imagenes, String Productos) {
        this.id_Pag_principal = id_Pag_principal;
        this.Ruleta_de_imagenes = Ruleta_de_imagenes;
        this.Productos = Productos;
    }

    public int getId_Pag_principal() {
        return id_Pag_principal;
    }

    public String getRuleta_de_imagenes() {
        return Ruleta_de_imagenes;
    }

    public String getProductos() {
        return Productos;
    }

    public void setId_Pag_principal(int id_Pag_principal) {
        this.id_Pag_principal = id_Pag_principal;
    }

    public void setRuleta_de_imagenes(String Ruleta_de_imagenes) {
        this.Ruleta_de_imagenes = Ruleta_de_imagenes;
    }

    public void setProductos(String Productos) {
        this.Productos = Productos;
    }
    
    public String mostrardatos() {
        return "Pag_principal{" + "id_Pag_principal=" + id_Pag_principal + ", Ruleta_de_imagenes=" + Ruleta_de_imagenes + ", Productos=" + Productos + '}';
    }
    
    
}
