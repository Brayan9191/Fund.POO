/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Registrarse {
    private int id_Registrarse;
    private int Telefono;
    private int Whatsapp;
    private String Nombre;
    private String Email;
    private String Contraseña;
    private String Direccion;

    public Registrarse(int id_Registrarse, int Telefono, int Whatsapp, String Nombre, String Email, String Contraseña, String Direccion) {
        this.id_Registrarse = id_Registrarse;
        this.Telefono = Telefono;
        this.Whatsapp = Whatsapp;
        this.Nombre = Nombre;
        this.Email = Email;
        this.Contraseña = Contraseña;
        this.Direccion = Direccion;
    }

    public int getId_Registrarse() {
        return id_Registrarse;
    }

    public int getTelefono() {
        return Telefono;
    }

    public int getWhatsapp() {
        return Whatsapp;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getEmail() {
        return Email;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setId_Registrarse(int id_Registrarse) {
        this.id_Registrarse = id_Registrarse;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }

    public void setWhatsapp(int Whatsapp) {
        this.Whatsapp = Whatsapp;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String mostrardatos() {
        return "Registrarse{" + "id_Registrarse=" + id_Registrarse + ", Telefono=" + Telefono + ", Whatsapp=" + Whatsapp + ", Nombre=" + Nombre + ", Email=" + Email + ", Contrase\u00f1a=" + Contraseña + ", Direccion=" + Direccion + '}';
    }
    
    
}
