/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Atencion_al_cliente {
    private int id_Atencion_al_cliente;
    private String Horario;
    private String Correo;
    private int Lin_telefonica;

    public Atencion_al_cliente(int Atencion_al_cliente, String Horario, String Correo, int Lin_telefonica) {
        this.id_Atencion_al_cliente = Atencion_al_cliente;
        this.Horario = Horario;
        this.Correo = Correo;
        this.Lin_telefonica = Lin_telefonica;
    }

    //get
    
    public int getAtencion_al_cliente() {
        return id_Atencion_al_cliente;
    }

    public String getHorario() {
        return Horario;
    }

    public String getCorreo() {
        return Correo;
    }

    public int getLin_telefonica() {
        return Lin_telefonica;
    }

    //set
    
    public void setId_Atencion_al_cliente(int id_Atencion_al_cliente) {
        this.id_Atencion_al_cliente = id_Atencion_al_cliente;
    }

    public void setHorario(String Horario) {
        this.Horario = Horario;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public void setLin_telefonica(int Lin_telefonica) {
        this.Lin_telefonica = Lin_telefonica;
    }

    
    
    public String mostrardatos() {
        return "Atencion_al_cliente{" + "Atencion_al_cliente=" + id_Atencion_al_cliente + ", Horario=" + Horario + ", Correo=" + Correo + ", Lin_telefonica=" + Lin_telefonica + '}';
    }
    
    
}
