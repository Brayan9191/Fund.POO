/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author blanc
 */
public class Perfil {
    private int Perfil;
    private String Direccion;
    private int Telefono;
    private int Whatsapp;
    private String Nombre;
    private String Contraseña;
    private String Editar;

    public Perfil(int Perfil, String Direccion, int Telefono, int Whatsapp, String Nombre, String Contraseña, String Editar) {
        this.Perfil = Perfil;
        this.Direccion = Direccion;
        this.Telefono = Telefono;
        this.Whatsapp = Whatsapp;
        this.Nombre = Nombre;
        this.Contraseña = Contraseña;
        this.Editar = Editar;
    }

    public int getPerfil() {
        return Perfil;
    }

    public String getDireccion() {
        return Direccion;
    }

    public int getTelefono() {
        return Telefono;
    }

    public int getWhatsapp() {
        return Whatsapp;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public String getEditar() {
        return Editar;
    }

    public void setPerfil(int Perfil) {
        this.Perfil = Perfil;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public void setTelefono(int Telefono) {
        this.Telefono = Telefono;
    }

    public void setWhatsapp(int Whatsapp) {
        this.Whatsapp = Whatsapp;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }

    public void setEditar(String Editar) {
        this.Editar = Editar;
    }
    
    public String mostrardatos() {
        return "Perfil{" + "Perfil=" + Perfil + ", Direccion=" + Direccion + ", Telefono=" + Telefono + ", Whatsapp=" + Whatsapp + ", Nombre=" + Nombre + ", Contrase\u00f1a=" + Contraseña + ", Editar=" + Editar + '}';
    }
    
    
}
