/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Filtros {
    private int id_Filtros;
    private String Diseño;
    private String Color;
    private String Tipo;
    private String Material;
    private String Gama_precio;

    public Filtros(int id_Filtros, String Diseño, String Color, String Tipo, String Material, String Gama_precio) {
        this.id_Filtros = id_Filtros;
        this.Diseño = Diseño;
        this.Color = Color;
        this.Tipo = Tipo;
        this.Material = Material;
        this.Gama_precio = Gama_precio;
    }

    public int getId_Filtros() {
        return id_Filtros;
    }

    public String getDiseño() {
        return Diseño;
    }

    public String getColor() {
        return Color;
    }

    public String getTipo() {
        return Tipo;
    }

    public String getMaterial() {
        return Material;
    }

    public String getGama_precio() {
        return Gama_precio;
    }

    public void setId_Filtros(int id_Filtros) {
        this.id_Filtros = id_Filtros;
    }

    public void setDiseño(String Diseño) {
        this.Diseño = Diseño;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public void setMaterial(String Material) {
        this.Material = Material;
    }

    public void setGama_precio(String Gama_precio) {
        this.Gama_precio = Gama_precio;
    }

    public String mostrardatos() {
        return "Filtros{" + "id_Filtros=" + id_Filtros + ", Dise\u00f1o=" + Diseño + ", Color=" + Color + ", Tipo=" + Tipo + ", Material=" + Material + ", Gama_precio=" + Gama_precio + '}';
    }
    
    
}
