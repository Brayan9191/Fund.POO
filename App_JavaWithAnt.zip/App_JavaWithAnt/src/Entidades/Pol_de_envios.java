/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Pol_de_envios {
    private int id_Pol_de_envios;
    private String Estado_pedido;
    private String Pol_de_envios;
    private String Seguimiento_de_pedido;

    public Pol_de_envios(int id_Pol_de_envios, String Estado_pedido, String Pol_de_envios, String Seguimiento_de_pedido) {
        this.id_Pol_de_envios = id_Pol_de_envios;
        this.Estado_pedido = Estado_pedido;
        this.Pol_de_envios = Pol_de_envios;
        this.Seguimiento_de_pedido = Seguimiento_de_pedido;
    }

    public int getId_Pol_de_envios() {
        return id_Pol_de_envios;
    }

    public String getEstado_pedido() {
        return Estado_pedido;
    }

    public String getPol_de_envios() {
        return Pol_de_envios;
    }

    public String getSeguimiento_de_pedido() {
        return Seguimiento_de_pedido;
    }

    public void setId_Pol_de_envios(int id_Pol_de_envios) {
        this.id_Pol_de_envios = id_Pol_de_envios;
    }

    public void setEstado_pedido(String Estado_pedido) {
        this.Estado_pedido = Estado_pedido;
    }

    public void setPol_de_envios(String Pol_de_envios) {
        this.Pol_de_envios = Pol_de_envios;
    }

    public void setSeguimiento_de_pedido(String Seguimiento_de_pedido) {
        this.Seguimiento_de_pedido = Seguimiento_de_pedido;
    }

    public String mostrardatos() {
        return "Pol_de_envios{" + "id_Pol_de_envios=" + id_Pol_de_envios + ", Estado_pedido=" + Estado_pedido + ", Pol_de_envios=" + Pol_de_envios + ", Seguimiento_de_pedido=" + Seguimiento_de_pedido + '}';
    }
    
    
}
