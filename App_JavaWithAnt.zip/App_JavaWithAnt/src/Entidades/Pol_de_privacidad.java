/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author blanc
 */
public class Pol_de_privacidad {
    private int id_Pol_de_privacidad;
    private String Pol_de_datos;
    private String Pol_de_privacidad;

    public Pol_de_privacidad(int id_Pol_de_privacidad, String Pol_de_datos, String Pol_de_privacidad) {
        this.id_Pol_de_privacidad = id_Pol_de_privacidad;
        this.Pol_de_datos = Pol_de_datos;
        this.Pol_de_privacidad = Pol_de_privacidad;
    }

    public int getId_Pol_de_privacidad() {
        return id_Pol_de_privacidad;
    }

    public String getPol_de_datos() {
        return Pol_de_datos;
    }

    public String getPol_de_privacidad() {
        return Pol_de_privacidad;
    }

    public void setId_Pol_de_privacidad(int id_Pol_de_privacidad) {
        this.id_Pol_de_privacidad = id_Pol_de_privacidad;
    }

    public void setPol_de_datos(String Pol_de_datos) {
        this.Pol_de_datos = Pol_de_datos;
    }

    public void setPol_de_privacidad(String Pol_de_privacidad) {
        this.Pol_de_privacidad = Pol_de_privacidad;
    }

    public String mostrardatos() {
        return "Pol_de_privacidad{" + "id_Pol_de_privacidad=" + id_Pol_de_privacidad + ", Pol_de_datos=" + Pol_de_datos + ", Pol_de_privacidad=" + Pol_de_privacidad + '}';
    }
    
    
}
