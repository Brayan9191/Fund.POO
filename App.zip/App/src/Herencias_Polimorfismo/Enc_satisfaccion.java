/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author blanc
 */
public class Enc_satisfaccion {
    private int Enc_satisfaccion;
    private String Pregunta;
    private String Enviar;

    public Enc_satisfaccion(int Enc_satisfaccion, String Pregunta, String Enviar) {
        this.Enc_satisfaccion = Enc_satisfaccion;
        this.Pregunta = Pregunta;
        this.Enviar = Enviar;
    }

    public int getEnc_satisfaccion() {
        return Enc_satisfaccion;
    }

    public String getPregunta() {
        return Pregunta;
    }

    public String getEnviar() {
        return Enviar;
    }

    public String mostrardatos() {
        return "Enc_satisfaccion{" + "Enc_satisfaccion=" + Enc_satisfaccion + ", Pregunta=" + Pregunta + ", Enviar=" + Enviar + '}';
    }
    
    
}
