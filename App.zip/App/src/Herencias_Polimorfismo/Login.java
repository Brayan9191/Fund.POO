/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Login {
    private int id_login;
    private int Telefono;
    private String Email;
    private String Contraseña;

    public Login(int id_login, int Telefono, String Email, String Contraseña) {
        this.id_login = id_login;
        this.Telefono = Telefono;
        this.Email = Email;
        this.Contraseña = Contraseña;
    }

    public int getId_login() {
        return id_login;
    }

    public int getTelefono() {
        return Telefono;
    }

    public String getEmail() {
        return Email;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public String mostrardatos() {
        return "Login{" + "id_login=" + id_login + ", Telefono=" + Telefono + ", Email=" + Email + ", Contrase\u00f1a=" + Contraseña + '}';
    }
    
    
}
