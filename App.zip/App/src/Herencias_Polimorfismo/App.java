/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class App {
    private int id_App;

    //getter
    
    public App(int id_App) {
        this.id_App = id_App;
    }

    public int getId_App() {
        return id_App;
    }

    //set

    public void setId_App(int id_App) {
        this.id_App = id_App;
    }
    
    //ToString
    
    public String mostrardatos() {
        return "App{" + "id_App=" + id_App + '}';
    }
    
    
}
