/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author blanc
 */
public class Vista_del_Producto {
    private int id_Vista_del_Producto;
    private String Descripcion;
    private String Imagenes;
    private String Marca_de_favorito;
    private int Precio;
    private String Nombre;
    private int Cant_en_carrito;
    private String Etiqueta_NuevoOferta;
    private String Color;

    public Vista_del_Producto(int id_Vista_del_Producto, String Descripcion, String Imagenes, String Marca_de_favorito, int Precio, String Nombre, int Cant_en_carrito, String Etiqueta_NuevoOferta, String Color) {
        this.id_Vista_del_Producto = id_Vista_del_Producto;
        this.Descripcion = Descripcion;
        this.Imagenes = Imagenes;
        this.Marca_de_favorito = Marca_de_favorito;
        this.Precio = Precio;
        this.Nombre = Nombre;
        this.Cant_en_carrito = Cant_en_carrito;
        this.Etiqueta_NuevoOferta = Etiqueta_NuevoOferta;
        this.Color = Color;
    }

    public int getId_Vista_del_Producto() {
        return id_Vista_del_Producto;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public String getImagenes() {
        return Imagenes;
    }

    public String getMarca_de_favorito() {
        return Marca_de_favorito;
    }

    public int getPrecio() {
        return Precio;
    }

    public String getNombre() {
        return Nombre;
    }

    public int getCant_en_carrito() {
        return Cant_en_carrito;
    }

    public String getEtiqueta_NuevoOferta() {
        return Etiqueta_NuevoOferta;
    }

    public String getColor() {
        return Color;
    }

    public String mostrardatos() {
        return "Vista_del_Producto{" + "id_Vista_del_Producto=" + id_Vista_del_Producto + ", Descripcion=" + Descripcion + ", Imagenes=" + Imagenes + ", Marca_de_favorito=" + Marca_de_favorito + ", Precio=" + Precio + ", Nombre=" + Nombre + ", Cant_en_carrito=" + Cant_en_carrito + ", Etiqueta_NuevoOferta=" + Etiqueta_NuevoOferta + ", Color=" + Color + '}';
    }
    
    
}
