/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Para_ti {
    private int id_Para_ti;
    private String Productos;
    private String Filtros;

    public Para_ti(int id_Para_ti, String Productos, String Filtros) {
        this.id_Para_ti = id_Para_ti;
        this.Productos = Productos;
        this.Filtros = Filtros;
    }

    public int getId_Para_ti() {
        return id_Para_ti;
    }

    public String getProductos() {
        return Productos;
    }

    public String getFiltros() {
        return Filtros;
    }
    
    public String mostrardatos() {
        return "Para_ti{" + "id_Para_ti=" + id_Para_ti + ", Productos=" + Productos + ", Filtros=" + Filtros + '}';
    }
    
    
}
