/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author blanc
 */
public class Guia_de_tallas {
    private int id_Guia_de_tallas;
    private String Enterizo;
    private String Brasier;
    private String Falda;

    public Guia_de_tallas(int id_Guia_de_tallas, String Enterizo, String Brasier, String Falda) {
        this.id_Guia_de_tallas = id_Guia_de_tallas;
        this.Enterizo = Enterizo;
        this.Brasier = Brasier;
        this.Falda = Falda;
    }

    public int getId_Guia_de_tallas() {
        return id_Guia_de_tallas;
    }

    public String getEnterizo() {
        return Enterizo;
    }

    public String getBrasier() {
        return Brasier;
    }

    public String getFalda() {
        return Falda;
    }

    public void setId_Guia_de_tallas(int id_Guia_de_tallas) {
        this.id_Guia_de_tallas = id_Guia_de_tallas;
    }

    public void setEnterizo(String Enterizo) {
        this.Enterizo = Enterizo;
    }

    public void setBrasier(String Brasier) {
        this.Brasier = Brasier;
    }

    public void setFalda(String Falda) {
        this.Falda = Falda;
    }

    public String mostrardatos() {
        return "Guia_de_tallas{" + "id_Guia_de_tallas=" + id_Guia_de_tallas + ", Enterizo=" + Enterizo + ", Brasier=" + Brasier + ", Falda=" + Falda + '}';
    }
    
    
}
