/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Herencias_Polimorfismo;

/**
 *
 * @author RPR-C80A404ES
 */
public class Paginas {
    private int id_Paginas;
    private int Producto;
    private int Atencion_cliente;
    private String Informacion;

    public Paginas(int id_Paginas, int Producto, int Atencion_cliente, String Informacion) {
        this.id_Paginas = id_Paginas;
        this.Producto = Producto;
        this.Atencion_cliente = Atencion_cliente;
        this.Informacion = Informacion;
    }

    public int getProducto() {
        return Producto;
    }

    public int getAtencion_cliente() {
        return Atencion_cliente;
    }

    public String getInformacion() {
        return Informacion;
    }

    public String mostrardatos() {
        return "Paginas{" + "id_Paginas=" + id_Paginas + ", Producto=" + Producto + ", Atencion_cliente=" + Atencion_cliente + ", Informacion=" + Informacion + '}';
    }
    
    
}
